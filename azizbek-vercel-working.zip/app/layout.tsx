
import './globals.css';

export const metadata = {
  title: 'Azizbek Xolov Dastafka',
  description: 'Simple Vercel deploy test',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
