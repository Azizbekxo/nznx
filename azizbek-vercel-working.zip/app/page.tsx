
export default function Home() {
  return (
    <main className="flex min-h-screen items-center justify-center">
      <h1 className="text-4xl font-bold">Sayt ishlayapti! (Azizbek Xolov)</h1>
    </main>
  );
}
